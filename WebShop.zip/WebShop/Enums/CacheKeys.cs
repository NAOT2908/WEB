﻿using System;

namespace WebShop.Enums
{
    public enum CacheKeys
    {
        Categories
    }
}
