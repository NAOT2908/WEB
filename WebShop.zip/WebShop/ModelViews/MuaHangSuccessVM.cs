﻿using MessagePack;
using System;
namespace WebShop.ModelViews
{
    public class MuaHangSuccessVM
    {
        
        public int DonHangID { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
       
    }
}
